# Telegram Bot Starter

This is a simple Telegram bot template ready to deploy on Koyeb or other Node.js environments.